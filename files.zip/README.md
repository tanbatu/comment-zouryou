![コメント増量](https://i.imgur.com/WoHFr2O.png "コメント増量")

コメント増量は、ニコニコ動画のコメント数を増量、及び全コメ表示がブラウザ上で出来る拡張機能です。

## プレビュー 
![コメント増量](https://i.imgur.com/dJTxufy.jpg "コメント増量")

![コメント増量](https://i.imgur.com/t6A8KYm.jpg "コメント増量")
## インストール
1.[リリースページより](https://github.com/tanbatu/comment-zouryou/releases)Source code (zip)をダウンロード、 展開する。

2.Chromeで「<strong>chrome://extensions</strong>」にアクセスする。

3.右上のデベロッパーモードをオンにして, 「<strong>パッケージ化されていない拡張機能を読み込む</strong>」を選択し、 1.でダウンロードしたフォルダを選択する。

## 使い方
[note記事を御覧ください。](https://note.com/tanbatu/n/n3837f4137cd9)

## 注意
大量のコメントを処理する為、コンピューターのスペックによってはフリーズする恐れがあります。

## スペシャルサンクス
XPAさんのコメント描画ライブラリ「niconicomments」を使用させて頂きました。
https://github.com/xpadev-net/niconicomments
